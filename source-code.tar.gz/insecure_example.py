# BAD EXAMPLE - DO NOT USE IN PRODUCTION
# This file demonstrates what NOT to do

import requests

# SECURITY VIOLATION: Hardcoded AWS credentials
AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE"
AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"

# SECURITY VIOLATION: Hardcoded API key
API_KEY = "sk-1234567890abcdef"

# SECURITY VIOLATION: Hardcoded database password
DB_PASSWORD = "super_secret_password123"

def insecure_ml_job():
    """This is an example of insecure code with hardcoded secrets"""
    
    # Using hardcoded credentials - NEVER DO THIS
    headers = {
        'Authorization': f'Bearer {API_KEY}',
        'Content-Type': 'application/json'
    }
    
    # Database connection with hardcoded password - NEVER DO THIS
    db_config = {
        'host': 'localhost',
        'user': 'admin',
        'password': DB_PASSWORD,
        'database': 'ml_data'
    }
    
    print("Running insecure ML job with hardcoded secrets")
    # This code would be flagged by security scanners

if __name__ == "__main__":
    insecure_ml_job()