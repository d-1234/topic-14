# ML Secrets Management POC

This POC demonstrates secure secrets and configuration management for ML jobs using AWS services and Terraform.

## Architecture

- **IAM Roles**: Least-privilege access for ML jobs
- **Secrets Manager**: Secure storage for API keys and sensitive data
- **Parameter Store**: Configuration management
- **Static Scanning**: CI/CD pipeline with TruffleHog and git-secrets

## Deployment

### AWS-Native Deployment
1. Deploy infrastructure:
```bash
terraform apply -auto-approve
```

2. Upload code and trigger pipeline:
```bash
./deploy-pipeline.sh
```

### AWS Services Deployed
- **CodePipeline**: Orchestrates CI/CD workflow
- **CodeBuild**: Security scanning and deployment
- **Secrets Manager**: Secure API key storage
- **Parameter Store**: Configuration management
- **S3**: Source code and artifacts storage

## Manual Testing
After deployment, test manually:
```bash
pip install boto3 truffleHog
python secure_ml_job.py
trufflehog filesystem . --only-verified
```

## Usage

### Secure Python Script
Run the secure ML job that retrieves secrets at runtime:
```bash
python secure_ml_job.py
```

### Security Scanning
The insecure_example.py file contains hardcoded secrets that will be detected by:
- TruffleHog
- git-secrets
- AWS CodeGuru Reviewer

## Key Benefits

1. **Code Security**: No secrets in source code
2. **Easy Rotation**: Update secrets without code changes
3. **Audit Trail**: CloudTrail logs all secret access
4. **Least Privilege**: IAM roles with minimal permissions

## Files

- `main.tf`: Core infrastructure
- `codepipeline.tf`: AWS CodePipeline and CodeBuild
- `secure_ml_job.py`: Secure implementation
- `insecure_example.py`: Example of what NOT to do
- `buildspec.yml`: Security scanning buildspec
- `terraform-buildspec.yml`: Terraform deployment buildspec
- `deploy-pipeline.sh`: Upload code and trigger pipeline
